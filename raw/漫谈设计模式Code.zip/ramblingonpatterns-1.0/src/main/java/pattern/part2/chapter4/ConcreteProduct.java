package pattern.part2.chapter4;

/**
 * Date: 2009-11-3
 * Time: 2:31:16
 */
public class ConcreteProduct implements Product {
}
