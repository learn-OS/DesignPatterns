package pattern.part2.chapter4;

/**
 * Date: 2009-11-3
 * Time: 2:29:59
 */
public interface Product {
}
