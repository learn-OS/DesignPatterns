package pattern.part2.chapter6.annotation;

/**
 * Date: Nov 19, 2010
 * Time: 4:37:42 PM
 *|| */
public class Service2Impl implements Service2 {
    public void execute() {
        System.out.println("Service2 is doing something.");
    }
}