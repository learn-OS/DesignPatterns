package pattern.part2.chapter6.constructor;

/**
 * Date: Nov 21, 2010
 * Time: 8:17:20 AM
 *|| */
public interface Service2 {
    void execute();
}