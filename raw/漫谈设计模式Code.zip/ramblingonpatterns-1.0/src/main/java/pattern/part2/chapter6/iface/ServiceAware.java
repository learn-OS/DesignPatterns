package pattern.part2.chapter6.iface;

/**
 * Date: Mar 16, 2011
 * Time: 12:32:23 AM
 */
public interface ServiceAware {
    void injectService(Service service);
}