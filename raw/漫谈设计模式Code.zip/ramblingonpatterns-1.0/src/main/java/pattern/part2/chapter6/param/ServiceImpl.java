package pattern.part2.chapter6.param;

/**
 * Date: Nov 19, 2010
 * Time: 4:37:42 PM
 *|| */
public class ServiceImpl implements Service {

    public void execute() {
        System.out.println("Service is doing something.");
    }
}