package pattern.part2.chapter6.setter;

/**
 * Date: Nov 19, 2010
 * Time: 4:33:34 PM
 *|| */
public interface Service1 {
    void execute();
}