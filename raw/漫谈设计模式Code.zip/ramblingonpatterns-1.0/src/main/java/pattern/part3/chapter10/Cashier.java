package pattern.part3.chapter10;

/**
 * Date: 2010-2-19
 * Time: 0:18:28
 */
public class Cashier {
    public void check() {
        System.out.println("Check the bill...");
    }
}
