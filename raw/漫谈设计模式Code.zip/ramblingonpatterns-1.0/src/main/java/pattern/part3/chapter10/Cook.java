package pattern.part3.chapter10;

/**
 * Date: 2010-2-19
 * Time: 0:18:57
 */
public class Cook {
    public void cookDish() {
        System.out.println("Cooking dishes...");
    }
}
