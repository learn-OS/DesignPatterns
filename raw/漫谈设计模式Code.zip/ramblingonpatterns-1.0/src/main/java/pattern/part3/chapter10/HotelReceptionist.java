package pattern.part3.chapter10;

/**
 * Date: 2010-2-19
 * Time: 0:18:17
 */
public class HotelReceptionist {
    public void subscribe() {
        System.out.println("Subscribe a table...");
    }
}
