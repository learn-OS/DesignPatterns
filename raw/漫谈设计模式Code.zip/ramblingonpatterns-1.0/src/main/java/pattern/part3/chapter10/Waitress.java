package pattern.part3.chapter10;

/**
 * Date: 2010-2-19
 * Time: 0:41:40
 */
public class Waitress {
    public void serveDishes() {
        System.out.println("Serving dishes...");
    }

    public void waitForAnOrder() {
        System.out.println("Waiting for the order...");
    }
}
