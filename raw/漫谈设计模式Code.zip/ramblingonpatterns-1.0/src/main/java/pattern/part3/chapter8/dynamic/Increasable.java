package pattern.part3.chapter8.dynamic;

/**
 * Date: Dec 20, 2010
 * Time: 7:41:21 PM
 *|| */
public interface Increasable {
    void increase(int delta);
}
