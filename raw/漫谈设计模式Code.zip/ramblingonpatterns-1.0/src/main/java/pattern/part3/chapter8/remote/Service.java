package pattern.part3.chapter8.remote;

/**
 * Date: Dec 7, 2010
 * Time: 8:37:22 PM
 *|| */
public interface Service {
    String hello();
}
