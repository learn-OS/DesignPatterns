package pattern.part3.chapter9;

/**
 * Date: 2010-2-15
 * Time: 11:50:32
 */
public interface IPeg {
    void insertIntoHole();
}