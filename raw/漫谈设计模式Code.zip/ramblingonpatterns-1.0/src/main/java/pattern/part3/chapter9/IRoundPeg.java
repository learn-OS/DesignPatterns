package pattern.part3.chapter9;

/**
 * Date: 2010-2-15
 * Time: 11:46:28
 */
public interface IRoundPeg {
    void insertIntoRoundHole();
}