package pattern.part3.chapter9;

/**
 * Date: 2010-2-15
 * Time: 11:55:40
 */
public class SquarePeg implements IPeg {
    @Override
    public void insertIntoHole() {
        System.out.println("I'm inserting into square hole...");
        //other logic...
    }
}
