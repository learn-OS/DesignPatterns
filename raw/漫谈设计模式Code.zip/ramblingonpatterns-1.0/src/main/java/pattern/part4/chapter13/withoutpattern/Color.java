package pattern.part4.chapter13.withoutpattern;

/**
 * Date: 2010-7-25
 * Time: 11:16:42
 */
public enum Color {
    RED,
    GREEN,
    BLUE
}
