package pattern.part4.chapter14.pattern;

/**
 * Date: 2010-8-15
 * Time: 12:01:35
 */
public interface StockBuyer {
    void update(float price);
}
