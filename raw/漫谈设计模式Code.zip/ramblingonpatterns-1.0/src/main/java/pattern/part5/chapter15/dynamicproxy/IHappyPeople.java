package pattern.part5.chapter15.dynamicproxy;

/**
 * Date: Jul 1, 2010
 * Time: 6:11:16 PM
 */
public interface IHappyPeople {
    void celebrateSpringFestival();

    void subscribeTicket();

    void travel();

    void celebrate();
}