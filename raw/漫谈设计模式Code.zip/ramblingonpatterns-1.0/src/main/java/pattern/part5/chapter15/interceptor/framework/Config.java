package pattern.part5.chapter15.interceptor.framework;

/**
 * User: liujih
 * Date: Mar 29, 2011
 * Time: 3:35:39 PM
 */
public class Config {
    private String methodName;

    public Config(String methodName) {
        this.methodName = methodName;
    }

    public String getMethodName() {
        return methodName;
    }
}
