package pattern.part5.chapter16.refine.travellable;

/**
 * Date: Aug 2, 2010
 * Time: 5:27:53 PM
 */
public interface Travellable {
    void travel();
}