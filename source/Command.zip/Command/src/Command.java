/**  
 * Package:   
 *  
 * File: sd.java   
 *  
 * Author: wb009   Date: 2015��1��7��  
 *  
 * Copyright @ 2015 Corpration Name  
 *   
 */
public abstract class Command {
	
    
    protected Receiver receiver;
    
    public Command(Receiver receiver) {
        this.receiver = receiver;
    }
    
    public abstract void execute();
}
