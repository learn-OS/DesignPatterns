/**  
 * Package:   
 *  
 * File: Receiver.java   
 *  
 * Author: wb009   Date: 2015��1��7��  
 *  
 * Copyright @ 2015 Corpration Name  
 *   
 */


public class Invoker {

    private Command command;
    
    public void setCommand(Command command) {
        this.command = command;
    }
    
    public void execute() {
        command.execute();
    }
}
