/**  
 * Package:   
 *  
 * File: Receiver.java   
 *  
 * Author: wb009   Date: 2015��1��7��  
 *  
 * Copyright @ 2015 Corpration Name  
 *   
 */
public class Receiver {
//	  public void receive() {
//	        System.out.println("This is Receive class!");
//	    }

	public void request() {
		// TODO Auto-generated method stub
		 System.out.println("This is Receive class!");
	}

}
  