/**  
 * Package:   
 *  
 * File: Receiver.java   
 *  
 * Author: wb009   Date: 2015��1��7��  
 *  
 * Copyright @ 2015 Corpration Name  
 *   
 */


public class Test {

    public static void main(String[] args) {
        Receiver rec = new Receiver();
        Command cmd = new CommandImpl(rec);
//        cmd.execute();
        Invoker i = new Invoker();
        i.setCommand(cmd);
        i.execute();
    }
}

